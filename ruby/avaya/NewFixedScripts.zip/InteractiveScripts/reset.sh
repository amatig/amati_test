#!/bin/sh
sed -i 's/\-/\+/g' ./extensions.txt